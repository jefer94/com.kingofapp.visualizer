# Operating requirements:
## Wordpress
Have installed the plugins:
Json api
Json apis user
WP-CORS

## Steps to follow to set up the wordpress
Once installed and activated the plugins mentioned above:

1. Go to the section Setings-> CORS
  In the allowed domains field enter an asterisk (*)
2. Go to the section Setings-> Json api
  Check the User option without unchecking any of the others.
  Finally, click on the button save changes.
3. In the section Setings-> General
  Check the option '' Anyone can register ''
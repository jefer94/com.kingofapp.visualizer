#Requisitos de funcionamiento:
##Wordpress
Tener instalados los plugins:
Json api
Json apis user
WP-CORS

##Pasos a seguir para configurar el wordpress
Una ves instalados y activados los plugins mencionados arriba:

1. Valla a la sección Setings->CORS
  En el campo allowed domains introducir un asterisco(*)
2. Dirijase a la sección Setings->Json api
  Marque la opción User sin desmarcar ningúna de las restantes.
  Por último has click en el botón save changes.
3. En la sección Setings->General
  Marca la opción ''Anyone can register'' 
(function(){
  'use strict';

  angular
    .module('king.services.wordpresslogin', [])
    .run(['$rootScope', 'configService', '$location', 'structureHooks', service]);

  function service($scope, configService, $location, structureHooks) {
    var config   = configService.services.wordpresslogin.scope;
    var urls     = config.needLoginUrls;
    var loginUrl = '/wpaccountpro-XZ';
    var module   = {};

    if (configService.services && configService.services.wordpresslogin)
      load();

    function load() {
      console.log('[V] Loading wordpresslogin config...');
      module[loginUrl] = loginModule();
      structureHooks.addModule(module);
      $scope.$on('$routeChangeSuccess', daemon);
      daemon();
    }

    function daemon() {
      if (!localStorage.__WORDPRESS__) {
        var path = $location.path();
        if ( _.includes(urls, path) ) {
          localStorage.__LAST__ = path;
          $location.path(loginUrl);
        }
      }
    }

    function loginModule() {
      return {
        name: 'Wordpress account',
        identifier: 'wpaccountpro',
        type: 'A',
        showOn: {
          menu: false,
          market: false,
          dragDrop: false
        },
        view: config.modulelogin.view,
        files: config.modulelogin.files,
        scope: _.omit(config, 'modulelogin'),
        libs: config.modulelogin.libs
      };
    }
  };
}());

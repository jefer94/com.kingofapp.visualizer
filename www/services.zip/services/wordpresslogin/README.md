# Wordpress login module
## Requirements
* [JSON-API](https://wordpress.org/plugins/json-api/other_notes/)

[Documentation](http://www.parorrey.com/solutions/json-api-auth/)
* [JSON-USER](https://es.wordpress.org/plugins/json-api-user/other_notes/)
* [WP-CORS](https://es.wordpress.org/plugins/wp-cors/)

 Inside Settings > CORS.
 Set Allowed domains to *

## Incompatibilities
Can't work along with wordpresssingle or wordpressposts modules.

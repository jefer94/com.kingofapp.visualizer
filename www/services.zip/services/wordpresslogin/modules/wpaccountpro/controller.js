(function() {
  'use strict';

  angular
    .module('wpaccountpro', [])
    .controller('wpaccountproController', wpaccountproController);

  wpaccountproController.$inject = ['$scope', 'structureService', '$location', '$http', '$window', 'wordpressService'];

  function wpaccountproController($scope, structureService, $location, $http, $window, wordpressService) {
    // Register upper level modules
    structureService.registerModule($location, $scope, 'wpaccountpro');
    // Start wpaccountproController content
    $scope.toggleRegister = toggleRegister;
    $scope.logout         = logout;
    $scope.send           = send;
    $scope.lastPage       = lastPage;
    $scope.model          = {};
    $scope.auth           = localStorage.__WORDPRESS__;
    $scope.ready          = true;

    var config    = $scope.wpaccountpro.modulescope;
    var key       = config.key;
    var oauth     = 'https://' + _.replace(config.domain, /(^https?:\/\/|\/$)/g, '') + '/wp-json/oauth2';
    var wordpress = wordpressService(config.domain, config.apiBase);
    var login     = wordpress.login;
    var users     = wordpress.users;

    init();

    function init() {
      var token = query('access_token');
      var type  = query('token_type');
      if (token || type) {
        localStorage.__WORDPRESS__ = token;
        $scope.auth = localStorage.__WORDPRESS__;
        console.log($location.url())
        homeRedirect();
      }
    }

    // sometimes, the callback return the query string with '#' instead of '?'
    function query(key) {
      var word = _.head( _.words(location.href, RegExp(key + '=[\\s\\S]+&')) );
      return _.replace(word, RegExp('(' + key + '=|&)', 'g'), '')
    }

    function send() {
      var key         = config.apiKey;
      var secret      = config.apiSecret;
      login({
        client_id     : config.apiKey,
        redirect_uri  : encodeURIComponent( location.href ),
        response_type : 'token'
      });
    }

    function homeRedirect() {
      var url = localStorage.__LAST__ || structureService.get().config.index;
      localStorage.removeItem('__LAST__');
      $scope.wpaccountpro.status = "User logged in!!";
      $location.url(url);
    }

    function toggleRegister() {
      $scope.model.register = !$scope.model.register;
    }

    function logout() {
      localStorage.clear();
      var cookies = document.cookie.split(';');

      _.each(cookies, function(cookie) {
        var pos  = _.indexOf(cookie, '=');
        var name = pos > -1 ? cookie.substr(0, pos) : cookie;
        document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT';
      });

      $scope.auth = false;
    }

    function lastPage() {
      if (localStorage.__LAST__) {
        localStorage.removeItem('__LAST__');
        history.go(-2);
      }
      else
        history.back();
    }
    // --- End wpaccountproController content ---
  }
}());
